# The Shell

Simple theme for [Ghost](http://github.com/tryghost/ghost/).

* Pure CSS
* Web Safe fonts

* Added Google Analytics, Disqus and syntax highlighting support by [@AlphaCluster](https://github.com/AlphaCluster) - version without this features available in 'Shell_0.1' branch



You can find live example [here](http://ghostintheshell.ghost.io/).



